package Object::Remote::Null;

sub AUTOLOAD { }

sub DESTROY { }

1;
