package Log::Contextual::Role::Router::SetLogger;

use Moo::Role;

requires 'set_logger';

1;

