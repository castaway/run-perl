package Log::Contextual::Role::Router::WithLogger;

use Moo::Role;

requires 'with_logger';

1;

